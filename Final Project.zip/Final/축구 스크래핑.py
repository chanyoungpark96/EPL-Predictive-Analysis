import requests
import json
import pandas as pd
A = []
B = []
C = []
D = []
E = []
F = []
G = []
H = []
I = []
J = []
K = []
L = []
M = []
N = []
O = []
P = []
Q = []
R = []
S = []
T = []
U = []
V = []
W = []
X = []
Y = []
headers = {
    'sec-ch-ua': '"Chromium";v="118", "Google Chrome";v="118", "Not=A?Brand";v="99"',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Referer': 'https://www.kickest.it/en/premier-league/stats/players/table/2021-2022?matchdays=19+18+17+16+15+14+13+12+11+10+9+8+7+6+5+4+3+2+1&mode=2',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua-mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/117.0',
    'sec-ch-ua-platform': '"macOS"',
}

params = {
    'category': '1',
    'season': '8',
    'matchdays': '19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1',
    'mode': '2',
    'language': 'en',
}

res = requests.get('https://www.kickest.it/dev/stats/players/table/getStats', params=params, headers=headers)
itemlist = json.loads(res.text)
for i in range(480):#480
    content = itemlist['data'][i]
    A.append(content['player'])
    B.append(content['position'])
    C.append(content['team'])
    D.append(float(content['kickest_pts']))
    E.append(float(content['kickest_cr']))
    F.append(float(content['kickest_plus']))
    G.append(float(content['apps']))
    H.append(float(content['starter']))
    I.append(float(content['mins']))
    J.append(float(content['goals']))
    K.append(float(content['total_shots']))
    L.append(float(content['on_target_shots']))
    M.append(float(content['penalty_goals']))
    N.append(float(content['won_dribbling']))
    O.append(float(content['assists']))
    P.append(float(content['accurate_passes']))
    Q.append(float(content['key_passes']))
    R.append(float(content['fouls_made']))
    S.append(float(content['fouls_received']))
    T.append(float(content['yellow_cards']))
    U.append(float(content['red_cards']))
    V.append(float(content['ball_recoveries']))
    W.append(float(content['tackles']))
    X.append(float(content['clean_sheets']))
    Y.append(float(content['saves']))
    


print(A,B,C,D,E,F,G,H,I,G,K,L,M,N,O,P,Q,R,S,T,U,V,W,len(X),len(Y))
data =  {
        'Player': A,
        'Pos': B,
        'Team': C,
        'PTS': D,
        'CR': E,
        'Plus': F,
        'Apps': G,
        'Starter': H,
        'Mins': I,
        'Goals': J,
        'Shots': K,
        'On Tar. Shots': L,
        'Pen Goals': M,
        'Successful Dribbles': N,
        'Ast': O,
        'Acc Pass': P,
        'Key Pass': Q,
        'Fouls': R,
        'Was Fouled': S,
        'YC': T,
        'RC': U,
        'Rec Ball': V,
        'Tackles': W,
        'Clean Sheets': X,
        'Saves': Y
    }
df = pd.DataFrame(data = data, columns = ['Player', 'Pos', 'Team', 'PTS', 'CR', 'Plus', 'Apps', 'Starter', 'Mins', 'Goals', 'Shots', 'On Tar. Shots', 'Pen Goals', 'Successful Dribbles', 'Ast', 'Acc Pass', 'Key Pass', 'Fouls', 'Was Fouled', 'YC', 'RC', 'Rec Ball', 'Tackles', 'Clean Sheets', 'Saves'])
df = df.sort_values(by='PTS',ascending = False)
df = df.reset_index(drop=True)
df.index=df.index+1
df.to_excel('축구.xlsx')